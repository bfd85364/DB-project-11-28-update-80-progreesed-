package com.example.database_project_local_item_app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class vagetablePageFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.vagetable_page, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        ImageButton gingerButton = view.findViewById(R.id.ginger);

        if(gingerButton != null){
            gingerButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1603491973";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton galicButton = view.findViewById(R.id.galic);
        if(galicButton != null){
            galicButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=512664";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton gogumaButton = view.findViewById(R.id.goguma);
        if(gogumaButton != null){
            gogumaButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1763100018";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton potatoButton = view.findViewById(R.id.potato);
        if(potatoButton != null){
            potatoButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1759988943";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton pepperButton = view.findViewById(R.id.pepper);
        if(pepperButton != null){
            pepperButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1714625806";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton yakmaButton = view.findViewById(R.id.yakma);
        if(yakmaButton != null){
            yakmaButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1640060030";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton onionButton = view.findViewById(R.id.onion);
        if(onionButton != null){
            onionButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1758693178";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton spicyButton = view.findViewById(R.id.spicy);
        if(spicyButton != null){
            spicyButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1729579956";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton pumkinButton = view.findViewById(R.id.pumkin);
        if(pumkinButton != null){
            pumkinButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1754906924";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton homeButton = view.findViewById(R.id.homebutton);

        if(homeButton != null){
            homeButton.setOnClickListener(v -> {
                moveFragment(new HomeFragment());
            });
        }
    }

    private void moveFragment(Fragment fragment) {
        if (getActivity() != null){
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container_view, fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }
}