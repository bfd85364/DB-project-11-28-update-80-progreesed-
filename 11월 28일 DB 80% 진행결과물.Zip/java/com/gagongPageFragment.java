package com.example.database_project_local_item_app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class gagongPageFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.gagong_page, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        ImageButton applebitButton = view.findViewById(R.id.apple_bit);
        if (applebitButton != null) {
            applebitButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1612943638";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton grape_juiceButton = view.findViewById(R.id.grape_jucie);
        if (grape_juiceButton != null) {
            grape_juiceButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570801002";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton odiButton = view.findViewById(R.id.odi);
        if (odiButton != null) {
            odiButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1693262285";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton yangbaechuButton = view.findViewById(R.id.yangbaechu);
        if (yangbaechuButton != null) {
            yangbaechuButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570791523";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton bokbunjaButton = view.findViewById(R.id.bokbunja);
        if (bokbunjaButton != null) {
            bokbunjaButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570783684";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton hwangdoButton = view.findViewById(R.id.hwangdo);
        if (hwangdoButton != null) {
            hwangdoButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1763607966";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton jjolmeonButton = view.findViewById(R.id.jjolmeon);
        if (jjolmeonButton != null) {
            jjolmeonButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1641027646";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton yukpoButton = view.findViewById(R.id.yukpo);
        if (yukpoButton != null) {
            yukpoButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1709876458";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton hobackButton = view.findViewById(R.id.sikcho);
        if (hobackButton != null) {
            hobackButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570801317";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton homeButton = view.findViewById(R.id.homebutton);

        if(homeButton != null){
            homeButton.setOnClickListener(v -> {
                moveFragment(new HomeFragment());
            });
        }
    }

    private void moveFragment(Fragment fragment) {
        if (getActivity() != null){
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container_view, fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }
}