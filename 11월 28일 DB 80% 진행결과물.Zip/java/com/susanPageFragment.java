package com.example.database_project_local_item_app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class susanPageFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.susan_page, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        ImageButton crabButton = view.findViewById(R.id.crab);
        if(crabButton != null){
            crabButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1664512249";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton octopusButton = view.findViewById(R.id.octopus);
        if(octopusButton != null){
            octopusButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1705654612";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton andongfishButton = view.findViewById(R.id.andong_highschoolfish);
        if(andongfishButton != null){
            andongfishButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570782620";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton gwamegiButton= view.findViewById(R.id.gwamegi);
        if(gwamegiButton != null){
            gwamegiButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1141838";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton squidButton= view.findViewById(R.id.squid);
        if(squidButton != null){
            squidButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1713232277";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton golbangyiButton= view.findViewById(R.id.golbangyi);
        if(golbangyiButton != null){
            golbangyiButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1734150655";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }


        ImageButton junbokButton= view.findViewById(R.id.junbok);
        if(junbokButton != null){
            junbokButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570793958";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton dasimaButton= view.findViewById(R.id.dasima);
        if(dasimaButton != null){
            dasimaButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570793361";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton jutButton= view.findViewById(R.id.jut);
        if(jutButton != null){
            jutButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1622013201";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }



        ImageButton homeButton = view.findViewById(R.id.homebutton);

        if(homeButton != null){
            homeButton.setOnClickListener(v -> {
                moveFragment(new HomeFragment());
            });
        }
    }

    private void moveFragment(Fragment fragment) {
        if (getActivity() != null){
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container_view, fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }
}