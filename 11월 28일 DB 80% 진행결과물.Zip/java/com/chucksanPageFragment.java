package com.example.database_project_local_item_app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class chucksanPageFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.chucksan_page, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        ImageButton galbiButton = view.findViewById(R.id.galbi);
        if(galbiButton != null){
            galbiButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1613975725";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton bulgogiButton = view.findViewById(R.id.bulgogi);
        if(bulgogiButton != null){
            bulgogiButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570797030";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                    }
                });
            }

        ImageButton tomahawkButton = view.findViewById(R.id.tomahawk);
        if(tomahawkButton != null){
            tomahawkButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1617170146";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton sagolButton = view.findViewById(R.id.sagol);
        if(sagolButton != null){
            sagolButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570791183";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton samgeoypsalButton = view.findViewById(R.id.samgeoypsal);
        if(samgeoypsalButton != null){
            samgeoypsalButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1708588960";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton dungsimButton = view.findViewById(R.id.dungsim);
        if(dungsimButton != null){
            dungsimButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1547186560";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton nangdongButton = view.findViewById(R.id.nangdong);
        if(nangdongButton != null){
            nangdongButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1646199872";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton chickenButton = view.findViewById(R.id.chicken);
        if(chickenButton != null){
            chickenButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1695001522";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton bakedeggButton = view.findViewById(R.id.bakedegg);
        if(bakedeggButton != null){
            bakedeggButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1691987414";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton homeButton = view.findViewById(R.id.homebutton);
        if(homeButton != null){
            homeButton.setOnClickListener(v -> {
                moveFragment(new HomeFragment());
            });
        }
    }

private void moveFragment(Fragment fragment) {
         if (getActivity() != null){
             getActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container_view, fragment)
                .addToBackStack(null)
                .commit();
        }
    }
}