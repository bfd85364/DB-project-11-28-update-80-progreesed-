package com.example.database_project_local_item_app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class KimchCharmgirmPageFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.kimch_chamgirm_page, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState){
        super.onViewCreated(view, savedInstanceState);

        ImageButton bechukimchButton = view.findViewById(R.id.bechukimch);
        if (bechukimchButton != null) {
            bechukimchButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1742969065";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton chunggukjangButton = view.findViewById(R.id.chunggukjang);
        if (chunggukjangButton != null) {
            chunggukjangButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570785332";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton gochujangButton = view.findViewById(R.id.gochujang);
        if (gochujangButton != null) {
            gochujangButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570785279";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton blackcharmkkeButton = view.findViewById(R.id.blackcharmkke);
        if (blackcharmkkeButton != null) {
            blackcharmkkeButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1761355499";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton ddulkkeButton = view.findViewById(R.id.ddulkke);
        if (ddulkkeButton != null) {
            ddulkkeButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1740544223";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton ganjangButton = view.findViewById(R.id.ganjang);
        if (ganjangButton != null) {
            ganjangButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=535874";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton charmgirmButton = view.findViewById(R.id.charmgirm);
        if (charmgirmButton != null) {
            charmgirmButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570788743";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton kimchsokButton = view.findViewById(R.id.kimchsok);
        if (kimchsokButton != null) {
            kimchsokButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1761877305";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton meyolchjutkalButton = view.findViewById(R.id.meyolchjutkal);
        if (meyolchjutkalButton != null) {
            meyolchjutkalButton.setOnClickListener(v -> {
                String url = "https://www.cyso.co.kr/shop/item.php?it_id=1570797362";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));

                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(getContext(), "링크를 열 브라우저 앱이 없습니다.", Toast.LENGTH_LONG).show();
                }
            });
        }

        ImageButton homeButton = view.findViewById(R.id.homebutton);

        if(homeButton != null){
            homeButton.setOnClickListener(v -> {
                moveFragment(new HomeFragment());
            });
        }
    }

    private void moveFragment(Fragment fragment) {
        if (getActivity() != null){
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container_view, fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }
}